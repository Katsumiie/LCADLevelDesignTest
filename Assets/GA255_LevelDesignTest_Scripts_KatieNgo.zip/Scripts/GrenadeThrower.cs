using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GrenadeThrower : MonoBehaviour
{
    public GameObject grenadePrefab;

    public Transform grenadeSpawnLocation;      //Why might we want to have a grenade spawn location that isn't on "this.transform.position"?   A: Because this.transform.position is based on the world space position of the Transform gizmo. We want the grenadeSpawnLocation relative to the player, which is why we made it a child of the First Person Controller 

    [SerializeField] private float grenadeExplosionRadius = 5f;
    [SerializeField] private float grenadeExplosionForce = 15f;     //What does this [SerializeField] tag do to the variable that comes after it?   A: The SerializeField tag is used to make the private variables accessible without making them a public function 

    [SerializeField] private float grenadeThrowPower = 25f;

    void Update()
    {
        if(Input.GetMouseButtonDown(0))     //Which button is this?   A: Left mouse button 
        {
            ThrowGrenade();
        }
    }

    private void ThrowGrenade()     //When does this function get called?   A: When the grenade is thrown and hits the ground on impact 
    {
        GameObject go = Instantiate(grenadePrefab, grenadeSpawnLocation.position, this.transform.rotation);      //Please explain what this line does and what assigning it to "GameObject go" lets us do.   A: This line creates new GameObjects, which, in this case, is the grenadePrefab, during runtime. Basically allows you to shoot multiple grenades consecutively 

        go.GetComponent<Grenade>().Initialize(grenadeExplosionForce, grenadeExplosionRadius);

        go.GetComponent<Rigidbody>().AddForce(Camera.main.transform.forward * grenadeThrowPower);     //What is the point of calling AddForce on the rigidbody of the spawned object?   A: It fakes the illusion of the explosion effect/impact 
        //Why might we want to add force in the direction of the camera's forward instead of the player's forward?   A: Because we do not want to move the player from their position 
    }
}
